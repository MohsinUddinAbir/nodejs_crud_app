const authVerify = require("./AuthVerify");
const signVerify = require("./SignVerify");
const uploadFiles = require("./UploadFiles");
module.exports = {
   authVerify,
   signVerify,
   uploadFiles,
};
