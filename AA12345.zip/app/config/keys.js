module.exports = {
   DB_HOST: "localhost",
   DB_USER: "root",
   DB_PASS: "1234",
   DB_NAME: "AA12345",
   dialect: "mysql",
};
