# Social Network

Run project

Setup database settings from app/config/keys.js

```bash
npm install
npm start
```

Functionalities:

1. Signup process
2. Login process
3. Logout facility
4. User profile with uploaded thumbnails
5. Adding members as friends
6. Posting that each member can view
